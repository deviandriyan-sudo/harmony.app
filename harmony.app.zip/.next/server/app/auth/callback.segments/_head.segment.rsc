1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/26vd4wxwg_h78.js","/_next/static/chunks/14mrh2-p_w84d.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/26vd4wxwg_h78.js","/_next/static/chunks/14mrh2-p_w84d.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/_next/static/chunks/26vd4wxwg_h78.js","/_next/static/chunks/14mrh2-p_w84d.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"HARMONY"}],["$","meta","1",{"name":"description","content":"Human Attendance, Request, Monitoring & Leave System"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.0ix3oatk1ahc3.ico","sizes":"336x336","type":"image/x-icon"}],["$","$L5","3",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"1AhUYfMCOQiwabnD01M_7"}
