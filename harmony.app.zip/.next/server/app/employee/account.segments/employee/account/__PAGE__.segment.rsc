1:"$Sreact.fragment"
3:I[97367,["/_next/static/chunks/26vd4wxwg_h78.js","/_next/static/chunks/14mrh2-p_w84d.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"XNqlPFqtdFjluBkZTbTb1"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/employee/settings;307;"}
