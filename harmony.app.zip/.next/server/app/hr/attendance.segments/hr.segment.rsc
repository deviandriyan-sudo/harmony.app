1:"$Sreact.fragment"
2:I[92825,["/_next/static/chunks/26vd4wxwg_h78.js","/_next/static/chunks/14mrh2-p_w84d.js"],"ClientSegmentRoot"]
3:I[6183,["/_next/static/chunks/26vd4wxwg_h78.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/1mj6gzztfc7w4.js","/_next/static/chunks/01zgrsa4a-orl.js"],"default"]
4:I[39756,["/_next/static/chunks/26vd4wxwg_h78.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
5:I[37457,["/_next/static/chunks/26vd4wxwg_h78.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/1mj6gzztfc7w4.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/01zgrsa4a-orl.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"1AhUYfMCOQiwabnD01M_7"}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
