var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/attachments/route.js")
R.c("server/chunks/[externals]_next_dist_0iuj5m_._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1euxqdr.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_next-internal_server_app_api_attachments_route_actions_17wqrvo.js")
R.m(24060)
module.exports=R.m(24060).exports
