var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/access/route.js")
R.c("server/chunks/[root-of-the-server]__0oawzfs._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_access_route_actions_1kt8w5x.js")
R.m(59327)
module.exports=R.m(59327).exports
