var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/hr/leave/postpone-adjustments/route.js")
R.c("server/chunks/[root-of-the-server]__0u7tez2._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/1oeh_server_app_api_hr_leave_postpone-adjustments_route_actions_0ywt7bf.js")
R.m(86434)
module.exports=R.m(86434).exports
