var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/hr/leave/request-types/route.js")
R.c("server/chunks/[root-of-the-server]__1b9ouc1._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_hr_leave_request-types_route_actions_0hcomgx.js")
R.m(17891)
module.exports=R.m(17891).exports
