var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/hr/users/route.js")
R.c("server/chunks/[root-of-the-server]__1tm4ni5._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_hr_users_route_actions_18woceq.js")
R.m(30288)
module.exports=R.m(30288).exports
