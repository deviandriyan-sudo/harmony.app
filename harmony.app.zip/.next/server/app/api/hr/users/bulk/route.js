var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/hr/users/bulk/route.js")
R.c("server/chunks/[root-of-the-server]__0nh7m-_._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_hr_users_bulk_route_actions_01w0vdv.js")
R.m(81573)
module.exports=R.m(81573).exports
