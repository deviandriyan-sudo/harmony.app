var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/hr/users/change-email/route.js")
R.c("server/chunks/[root-of-the-server]__0hap0mu._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_11h6wme.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_hr_users_change-email_route_actions_10yl0et.js")
R.m(70489)
module.exports=R.m(70489).exports
