var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/hr/users/reset-password/route.js")
R.c("server/chunks/[root-of-the-server]__0hap0mu._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_041d6ps.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_hr_users_reset-password_route_actions_0it4k24.js")
R.m(11934)
module.exports=R.m(11934).exports
