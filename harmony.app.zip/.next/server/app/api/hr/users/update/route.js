var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/hr/users/update/route.js")
R.c("server/chunks/[root-of-the-server]__1pyyo-s._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_hr_users_update_route_actions_0ukr-dp.js")
R.m(88390)
module.exports=R.m(88390).exports
