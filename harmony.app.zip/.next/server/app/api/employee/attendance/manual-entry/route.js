var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/employee/attendance/manual-entry/route.js")
R.c("server/chunks/[externals]_next_dist_0iuj5m_._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0u6l6cz.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/1oeh_server_app_api_employee_attendance_manual-entry_route_actions_10f40ew.js")
R.m(9255)
module.exports=R.m(9255).exports
