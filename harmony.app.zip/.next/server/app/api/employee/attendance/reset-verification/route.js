var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/employee/attendance/reset-verification/route.js")
R.c("server/chunks/[externals]_next_dist_0iuj5m_._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1v2-sdg.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/1oeh_server_app_api_employee_attendance_reset-verification_route_actions_0ze1j1-.js")
R.m(8273)
module.exports=R.m(8273).exports
