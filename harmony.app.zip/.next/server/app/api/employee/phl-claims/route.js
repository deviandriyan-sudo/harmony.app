var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/employee/phl-claims/route.js")
R.c("server/chunks/[root-of-the-server]__1ger-yc._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0ohp0u8.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_employee_phl-claims_route_actions_0kfku7g.js")
R.m(27741)
module.exports=R.m(27741).exports
