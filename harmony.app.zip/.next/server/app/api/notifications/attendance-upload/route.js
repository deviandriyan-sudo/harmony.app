var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/attendance-upload/route.js")
R.c("server/chunks/[root-of-the-server]__0rhrbbv._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/1oeh_server_app_api_notifications_attendance-upload_route_actions_0abr2d6.js")
R.m(23130)
module.exports=R.m(23130).exports
