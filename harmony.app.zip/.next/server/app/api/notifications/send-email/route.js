var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/send-email/route.js")
R.c("server/chunks/[root-of-the-server]__0lu-alf._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1-hitkq.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_next-internal_server_app_api_notifications_send-email_route_actions_0uy-4g4.js")
R.m(98096)
module.exports=R.m(98096).exports
