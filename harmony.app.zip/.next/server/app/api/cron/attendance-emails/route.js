var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cron/attendance-emails/route.js")
R.c("server/chunks/[root-of-the-server]__11nb9r9._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_cron_attendance-emails_route_actions_007rekr.js")
R.m(15714)
module.exports=R.m(15714).exports
