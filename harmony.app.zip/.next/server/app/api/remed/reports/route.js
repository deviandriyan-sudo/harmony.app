var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/remed/reports/route.js")
R.c("server/chunks/[root-of-the-server]__1xpmk64._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_remed_reports_route_actions_0ed7yui.js")
R.m(96453)
module.exports=R.m(96453).exports
