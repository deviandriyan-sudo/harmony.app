var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/remed/dashboard/route.js")
R.c("server/chunks/[root-of-the-server]__0jbigdl._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_remed_dashboard_route_actions_0yi_r5w.js")
R.m(51986)
module.exports=R.m(51986).exports
