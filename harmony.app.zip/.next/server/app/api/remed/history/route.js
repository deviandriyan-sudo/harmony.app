var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/remed/history/route.js")
R.c("server/chunks/[root-of-the-server]__0p64j4o._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_remed_history_route_actions_1bp6_9c.js")
R.m(53350)
module.exports=R.m(53350).exports
