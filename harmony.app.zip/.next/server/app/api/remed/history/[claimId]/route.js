var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/remed/history/[claimId]/route.js")
R.c("server/chunks/[root-of-the-server]__1qj2acm._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_remed_history_[claimId]_route_actions_068r9-i.js")
R.m(13602)
module.exports=R.m(13602).exports
