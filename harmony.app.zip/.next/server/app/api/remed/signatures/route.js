var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/remed/signatures/route.js")
R.c("server/chunks/[root-of-the-server]__0n6lzjb._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_remed_signatures_route_actions_04k20vg.js")
R.m(41901)
module.exports=R.m(41901).exports
