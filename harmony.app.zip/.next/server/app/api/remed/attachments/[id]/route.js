var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/remed/attachments/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1dill26._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_remed_attachments_[id]_route_actions_1_ozgzj.js")
R.m(64532)
module.exports=R.m(64532).exports
