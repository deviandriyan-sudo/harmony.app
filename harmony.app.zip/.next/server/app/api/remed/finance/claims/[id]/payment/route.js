var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/remed/finance/claims/[id]/payment/route.js")
R.c("server/chunks/[root-of-the-server]__0h5ar1l._.js")
R.c("server/chunks/[root-of-the-server]__1_kct_7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/1oeh_server_app_api_remed_finance_claims_[id]_payment_route_actions_0ouj7ys.js")
R.m(2640)
module.exports=R.m(2640).exports
