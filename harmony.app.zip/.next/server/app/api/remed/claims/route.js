var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/remed/claims/route.js")
R.c("server/chunks/[root-of-the-server]__1gndx7o._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_16-id-e.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__1_kct_7._.js")
R.c("server/chunks/_next-internal_server_app_api_remed_claims_route_actions_1v_q21t.js")
R.m(55762)
module.exports=R.m(55762).exports
