var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/remed/claims/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1m_pwf1._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_remed_claims_[id]_route_actions_0k609hj.js")
R.m(82043)
module.exports=R.m(82043).exports
