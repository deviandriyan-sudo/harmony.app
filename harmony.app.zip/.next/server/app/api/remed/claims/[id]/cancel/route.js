var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/remed/claims/[id]/cancel/route.js")
R.c("server/chunks/[root-of-the-server]__0rmjh8d._.js")
R.c("server/chunks/[root-of-the-server]__1_kct_7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_next-internal_server_app_api_remed_claims_[id]_cancel_route_actions_12ab268.js")
R.m(63930)
module.exports=R.m(63930).exports
