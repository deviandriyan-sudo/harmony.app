var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/remed/hr/entitlements/route.js")
R.c("server/chunks/[root-of-the-server]__1kc_cmc._.js")
R.c("server/chunks/[root-of-the-server]__1_kct_7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_next-internal_server_app_api_remed_hr_entitlements_route_actions_1ze_a-8.js")
R.m(27083)
module.exports=R.m(27083).exports
