var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/remed/hr/claims/[id]/review/route.js")
R.c("server/chunks/[root-of-the-server]__0r_iqwf._.js")
R.c("server/chunks/[root-of-the-server]__1_kct_7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_next-internal_server_app_api_remed_hr_claims_[id]_review_route_actions_0x-g9u9.js")
R.m(49006)
module.exports=R.m(49006).exports
