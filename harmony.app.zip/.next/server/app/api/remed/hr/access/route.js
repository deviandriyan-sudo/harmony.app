var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/remed/hr/access/route.js")
R.c("server/chunks/[root-of-the-server]__1250jbt._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1ukfwtx.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_next-internal_server_app_api_remed_hr_access_route_actions_0gpc4ji.js")
R.m(98758)
module.exports=R.m(98758).exports
