var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/phl/work-requests/[id]/review/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_14e0v8b.js")
R.c("server/chunks/[root-of-the-server]__11hkui2._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/1oeh_server_app_api_phl_work-requests_[id]_review_route_actions_1t5lywn.js")
R.m(85456)
module.exports=R.m(85456).exports
