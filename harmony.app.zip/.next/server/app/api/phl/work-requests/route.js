var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/phl/work-requests/route.js")
R.c("server/chunks/[root-of-the-server]__11hkui2._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_150y9-o.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_phl_work-requests_route_actions_1r0m8zw.js")
R.m(95559)
module.exports=R.m(95559).exports
