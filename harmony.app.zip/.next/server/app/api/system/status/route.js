var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/system/status/route.js")
R.c("server/chunks/[root-of-the-server]__1bo4cnm._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_system_status_route_actions_13lfeve.js")
R.m(14724)
module.exports=R.m(14724).exports
